# Sulbha Aggarwal 

How to Run:
1) Put everything in one folder, File Names: train.txt, test.txt and Homework1NlpPartII.py
2) open Homework1NlpPartII.py using a python IDE or thru command-line
	a) IDE: Pun module button
	b) Command-Line: use 'cd' to open the directory where the files are saved.
		i) type 'python Homework1NlpPartII.py' then press ENTER.